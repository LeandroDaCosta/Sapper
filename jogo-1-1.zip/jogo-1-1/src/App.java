
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;
import java.util.Arrays;

public class App {

    static String jogada;
    static int tamanhoMatriz;
    static int quantidadeBomba;
    static int opc, vida;
    static int escolha;
    static int pontuacoes = 0;
    static int contadodor = 1;
    static Scanner in = new Scanner(System.in);
    static Random aleatorio = new Random();

    static int linhaObjetivo;
    static int colunaObjetivo;
    static int linhaJogador;
    static int colunaJogador;
    static String JOGADOR = "🐁";
    static String OBJECTIVO = "🧀";
    static String RELVA = "🌲";

    static String campo[][];

    public static void main(String[] args) throws Exception {
        // Lista que vai armazenar os Jogadores
        ArrayList<jogador> listasJogadores = new ArrayList<>();
        // variável que vai guardar o nosso tipo de dados jogador
        jogador jogador;
        boolean verificador = false;
        int escolhaPersonagem;
        do
        {
            menuinicio();
            System.out.println("Informe a sua Opcao");
            opc = in.nextInt();
            switch (opc)
            {

                case 1:

                    // Área de Configuração do Jogo
                    System.out.println("===========Configuração==========");
                    System.out.println("---------------------------------");
                    System.out.println("Digite o Tamanho da campo");
                    tamanhoMatriz = in.nextInt();
                    while (tamanhoMatriz < 5)
                    {
                        System.out.println("\n\n\n");
                        System.out.println("O tamanho Campo deve ter no mínimo 5 linhas e colunas");
                        System.out.println("Digite o Tamanho da campo");
                        tamanhoMatriz = in.nextInt();
                    }
                    System.out.println("Escolha o seu jogador : \n1-🐁\n2-🚑\n3-🚒");
                    escolhaPersonagem = in.nextInt();
                    switch (escolhaPersonagem)
                    {
                        case 1:
                            JOGADOR = "‍‍🐁‍‍";
                            OBJECTIVO = "🧀";
                            break;
                        case 2:
                            JOGADOR = "‍‍🚑‍‍";
                            OBJECTIVO = "🏥";
                            break;
                        case 3:
                            JOGADOR = "‍‍🚒‍‍";
                            OBJECTIVO = "🏚️";
                            break;
                    }
                    break;
                case 2:
                    if (tamanhoMatriz == 0)
                    {
                        System.out.println("Você deve configurar o tamanho do campo em Administrador!!");
                    } else
                    {
                        do
                        {
                            menujogo();
                            System.out.println("Informe A sua Escolha");
                            opc = in.nextInt();
                            in.nextLine();
                            switch (opc)
                            {
                                case 1:

                                    System.out.println("Digite o seu nome :");
                                    String nome = in.nextLine();
                                    System.out.println("dia :");
                                    int dia = in.nextInt();
                                    System.out.println("Mês :");
                                    int mes = in.nextInt();
                                    System.out.println("Ano :");
                                    int ano = in.nextInt();
                                    menuDificuldade();
                                    System.out.println("Escolha");
                                    escolha = in.nextInt();

                                    //while para caso for escolhido um Nível Inválido
                                    while (escolha != 1 && escolha != 2 && escolha != 3)
                                    {
                                        System.out.println("Nível Inválido");
                                        System.out.println("");
                                        System.out.println("");
                                        menuDificuldade();
                                        System.out.println("Escolha");
                                        escolha = in.nextInt();
                                    }
                                    in.nextLine();
                                    // IFs que determiman o número de vida e a quantodade das bombas
                                    if (escolha == 1)
                                    {
                                        vida = 5;
                                        quantidadeBomba = tamanhoMatriz * 2;
                                    } else if (escolha == 2)
                                    {
                                        vida = 3;
                                        quantidadeBomba = tamanhoMatriz * 3;
                                    } else
                                    {
                                        vida = 1;
                                        quantidadeBomba = tamanhoMatriz * 4;
                                    }
                                    // Criação do campo ou da matriz do jogo
                                    campo = new String[tamanhoMatriz][tamanhoMatriz];
                                    // preenchendo o campo com Relvas(*)
                                    for (int i = 0; i < tamanhoMatriz; i++)
                                    {
                                        for (int j = 0; j < tamanhoMatriz; j++)
                                        {
                                            campo[i][j] = RELVA;
                                        }
                                    }
                                    // Declaração do vetor que vai guardar as posições das bombas
                                    int bomba[];
                                    bomba = gerarBomba(quantidadeBomba, tamanhoMatriz);

                                    // localização do Objectivo
                                    linhaObjetivo = 0;
                                    colunaObjetivo = 0;

                                    // localização do Jogador
                                    linhaJogador = tamanhoMatriz - 1;
                                    colunaJogador = tamanhoMatriz - 1;

                                    // colocando o Jogador eo objectivo dentro do campo
                                    campo[linhaObjetivo][colunaObjetivo] = OBJECTIVO;
                                    campo[linhaJogador][colunaJogador] = JOGADOR;
                                    do
                                    {
                                        // Imprimindo o campo Completo
                                        campoMina(campo, tamanhoMatriz);
                                        System.out.println("Vida Restantes :" + vida);
                                        System.out.println("Pontuações :" + pontuacoes);
                                        System.out.println("");
                                        System.out.println("Digite a sua jogada ou N(Para Sair do jogo)!");
                                        jogada = in.nextLine();
                                        movimento(jogada);

                                        if (campo[linhaObjetivo][colunaObjetivo] == campo[linhaJogador][colunaJogador])
                                        {
                                            System.out.println("Parabens, voçê Ganhou!!!");
                                            apresentarMensagemVencedor();
                                        } else
                                        // For que verifica se no vetor das bombas tem uma bomba na mesma localização que o jogador na jogada efetuada
                                        {
                                            for (int i = 0; i < quantidadeBomba * 2; i += 2)
                                            {
                                                if (campo[bomba[i]][bomba[i + 1]] == campo[linhaJogador][colunaJogador])
                                                {
                                                    System.out.println("UPSS! Você pisou Mina...");
                                                    vida--;
                                                    verificador = true;
                                                    break;

                                                }
                                            }
                                        }
                                        // if que permite pontuar o jogador
                                        if (verificador == false)
                                        {
                                            pontuacoes += 5;
                                        }
                                        verificador = false;
                                        if (vida == 0)
                                        {
                                            System.out.println("Estás Bem Morto...");
                                            System.out.println("");
                                            apresentarMensagemMorte();
                                        } else if (vida == 10)
                                        {
                                            System.out.println("Jogo cancelado!");
                                            pontuacoes = 0;
                                        }
                                    } while (campo[linhaObjetivo][colunaObjetivo] != campo[linhaJogador][colunaJogador]
                                            && vida != 0 && vida != 10);
                                    jogador = new jogador(nome, dia, mes, ano, pontuacoes);
                                    listasJogadores.add(jogador);
                                    pontuacoes = 0;
                                    break;
                                case 2:
                                    intrucaoJogo();
                                    break;
                                case 3:
                                    if (listasJogadores.isEmpty())
                                    {
                                        System.out.println("Não Existe Nenhum Jogador no Pódio");
                                    } else
                                    {
                                        System.out.println("----------=====Pódio=====----------");
                                        ordenarPodio(listasJogadores);
                                    }
                                    break;
                                case 4:
                                    System.out.println("Vontado para Menú Principal");
                                    break;
                                default:
                                    System.out.println("Opção Inválida");
                                    break;
                            }
                        } while (opc != 4);
                    }
                    break;
                case 3:
                    System.out.println("Jogo terminado...");
                    break;
            }
        } while (opc != 3);

    }

    // Função para Gerar as Bombas no campo
    public static int[] gerarBomba(int tamanho, int tamanhoMatriz) {
        Random aleatorio = new Random();
        int bomba[] = new int[tamanho * 2];
        int linhaBomba;
        int colunaBomba;
        for (int i = 0; i < tamanho; i += 2)
        {
            linhaBomba = aleatorio.nextInt(tamanhoMatriz);
            colunaBomba = aleatorio.nextInt(tamanhoMatriz);
            while (linhaBomba == 0 & colunaBomba == 0
                    || linhaBomba == tamanhoMatriz - 1 & colunaBomba == tamanhoMatriz - 1)
            {
                linhaBomba = aleatorio.nextInt(tamanhoMatriz);
                colunaBomba = aleatorio.nextInt(tamanhoMatriz);
            }

            bomba[i] = linhaBomba;
            bomba[i + 1] = colunaBomba;

        }
        return bomba;
    }

    // Funcão para gerar campo minado!
    private static void campoMina(String campo[][], int tamanho) {
        for (int i = 0; i < tamanho; i++)
        {
            for (int j = 0; j < tamanho; j++)
            {
                System.out.print(campo[i][j]);
                System.out.print("\t");
            }
            System.out.println("");
            System.out.println("");
        }
    }

    // Função para Gerar as Menú de dificuldade
    public static void menuDificuldade() {
        System.out.println("##################################");
        System.out.println("#####-----Nível do jogo!-----#####");
        System.out.println("..................................");
        System.out.println("|1-Fácil                         |");
        System.out.println("..................................");
        System.out.println("|2-Médio                         |");
        System.out.println("..................................");
        System.out.println("|3-Difícil                       |");
        System.out.println("..................................");
        System.out.println("##################################");
        System.out.println("");
        System.out.println("");
    }

    // Função para Gerar as Menú do jogo
    public static void menujogo() {
        limpaTela();
        System.out.println("##################################");
        System.out.println("######-----Shaper 1.1-----######");
        System.out.println("..................................");
        System.out.println("| 1-Jogar                        |");
        System.out.println("..................................");
        System.out.println("| 2-Instruções                   |");
        System.out.println("..................................");
        System.out.println("| 3-Pódio                        |");
        System.out.println("..................................");
        System.out.println("| 4-Voltar para menú Principal   |");
        System.out.println("..................................");
        System.out.println("##################################");
    }

    // Função para Gerar as As Instruções do jogo
    public static void intrucaoJogo() {
        System.out.println("##########################################################");
        System.out.println("| O jogo consiste em atravessar o campo minado até a meta|");
        System.out.println("..........................................................");
        System.out.println("|sem esbarrar nas bombas que estarão escondidas no campo.|");
        System.out.println("..........................................................");
        System.out.println("|                                                        |");
        System.out.println("..........................................................");
        System.out.println("| Use as teclas w(cima),s(baixo),a(direita) e d(esquerda)|");
        System.out.println("..........................................................");
        System.out.println("|para se locomover no campo                              |");
        System.out.println("..........................................................");
        System.out.println("##########################################################");
        System.out.println("");
        System.out.println("");
    }

    // Função para Gerar as Menú de inicio
    public static void menuinicio() {
        limpaTela();
        System.out.println("\t\t\t######-----Saper 1.1-----######");
        System.out.println("");
        System.out.println("➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖\n"
                + "➖🟦🟦🟦🟦➖🟩🟩🟩🟩➖🟪🟪🟪🟪🟪➖🟧🟧🟧🟧➖🟥🟥🟥🟥🟥➖➖➖➖➖➖➖➖➖\n"
                + "➖🟦➖➖➖➖🟩➖➖🟩➖🟪➖➖➖🟪➖🟧➖➖➖➖🟥➖➖➖🟥➖➖➖➖➖➖➖➖➖➖\n"
                + "➖🟦➖➖➖➖🟩➖➖🟩➖🟪➖➖➖🟪➖🟧➖➖➖➖🟥➖➖➖🟥➖➖➖➖➖➖➖➖➖➖\n"
                + "➖🟦🟦🟦🟦➖🟩🟩🟩🟩➖🟪🟪🟪🟪🟪➖🟧🟧🟧🟧➖🟥➖🟥🟥🟥➖➖➖➖➖➖➖➖➖\n"
                + "➖➖➖➖🟦➖🟩➖➖🟩➖🟪➖➖➖➖➖🟧➖➖➖➖🟥➖🟥➖➖➖➖➖➖➖➖➖➖\n"
                + "➖➖➖➖🟦➖🟩➖➖🟩➖🟪➖➖➖➖➖🟧➖➖➖➖🟥➖➖🟥➖➖➖➖➖➖➖➖➖\n"
                + "➖🟦🟦🟦🟦➖🟩➖➖🟩➖🟪➖➖➖➖➖🟧🟧🟧🟧➖🟥➖➖➖🟥➖➖➖➖➖➖➖➖➖➖      \n"
                + "➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖➖");
        System.out.println("...............................");
        System.out.println("| 1-Administrador             |");
        System.out.println("...............................");
        System.out.println("| 2-Iniciar jogo              |");
        System.out.println("...............................");
        System.out.println("| 3-Sair                      |");
        System.out.println("...............................");

    }

    // Função para Gerar os movimento do jogador
    public static void movimento(String jogada) {
        switch (jogada)
        {
            case "w":
                
                if (linhaJogador - 1 < 0)
                {
                    System.out.println("posicao invalida");
                } else
                {
                    campo[linhaJogador][colunaJogador] = RELVA;

                    campo[--linhaJogador][colunaJogador] = JOGADOR;

                    for (int i = 0; i < tamanhoMatriz; i++)
                    {
                        for (int j = 0; j < tamanhoMatriz; j++)
                        {
                            if (campo[i][j] != JOGADOR)
                            {
                                campo[i][j] = RELVA;
                                campo[linhaObjetivo][colunaObjetivo] = OBJECTIVO;
                            }
                        }
                    }
                }

                break;
            case "s":
                //este if impede que o jogador va para uma posicao esquerda que nao existe
                 if (linhaJogador+1>tamanhoMatriz-1){
                                            System.out.println("jogada invalida");
                                        }
                                             
                                        else{
                                        campo[linhaJogador][colunaJogador] = RELVA;
                                        campo[++linhaJogador][colunaJogador] = JOGADOR;
                                   

                                        for (int i = 0; i < tamanhoMatriz; i++)
                                        {
                                            for (int j = 0; j < tamanhoMatriz; j++)
                                            {
                                                if (campo[i][j] != JOGADOR)
                                                {
                                                    campo[i][j] = RELVA;
                                                    campo[linhaObjetivo][colunaObjetivo] = OBJECTIVO;
                                                }
                                            }
                                        }
                                        }
                break;
            case "a":
                if (colunaJogador - 1 < 0)
                {
                    //este if impede que o jogador va para uma posicao esquerda que nao existe
                    System.out.println("posicao invalida");
                } else
                {

                    campo[linhaJogador][colunaJogador] = RELVA;
                    campo[linhaJogador][--colunaJogador] = JOGADOR;

                    for (int i = 0; i < tamanhoMatriz; i++)
                    {
                        for (int j = 0; j < tamanhoMatriz; j++)
                        {
                            if (campo[i][j] != JOGADOR)
                            {
                                campo[i][j] = RELVA;
                                campo[linhaObjetivo][colunaObjetivo] = OBJECTIVO;
                            }
                        }
                    }
                }
                break;
            case "d":
                //este if verifica se o jogador tentou aceder uma posicao a direita inexistente
                                        if (colunaJogador + 1 >= tamanhoMatriz-1){
                                            System.out.println("jogada invalida !!");}
                                        else{
                                        campo[linhaJogador][colunaJogador] = RELVA;
                                        campo[linhaJogador][++colunaJogador] = JOGADOR;
                                       
                                        for (int i = 0; i < tamanhoMatriz; i++)
                                        {
                                            for (int j = 0; j < tamanhoMatriz; j++)
                                            {
                                                if (campo[i][j] != JOGADOR)
                                                {
                                                    campo[i][j] = RELVA;
                                                    campo[linhaObjetivo][colunaObjetivo] = OBJECTIVO;
                                                }
                                            }
                                        }
                                        
                                        }
                break;
            default:
                System.out.println("Jogada Inválida!");
                break;
        }
    }

    // Função para Listar e Ordenar as Pontuações dos Jogadores
    public static void ordenarPodio(ArrayList<jogador> jogadrs) {
        jogador aux;
        jogador vetor[] = new jogador[jogadrs.size()];
        for (int i = 0; i < vetor.length; i++)
        {
            vetor[i] = jogadrs.get(i);
        }
        for (int i = 0; i < vetor.length - 1; i++)
        {
            for (int j = i + 1; j < vetor.length; j++)
            {
                if (vetor[i].pontuacao < vetor[i + 1].pontuacao)
                {
                    aux = vetor[i];
                    vetor[i] = vetor[i + 1];
                    vetor[i + 1] = aux;
                }
            }
        }
        for (int i = 0; i < vetor.length; i++)
        {
            System.out.println((i + 1) + "º - " + vetor[i].nome + "-------------------------" + vetor[i].pontuacao + " Pts");
        }
    }

    static void apresentarMensagemMorte() {
        //esta funcao apresenta a mensagem de morte ao utilizador
        System.out.println("`⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣤⠀⠀\n"
                + "⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣤⣴⣶⣾⣿⣿⣿⣿⣿⡏⡆⠀\n"
                + "⠀⠀⠀⠀⠀⠀⠀⣠⣾⠿⠛⠋⠉⠉⠉⠈⠉⠛⠛⢳⡇⠀\n"
                + "⠀⠀⠀⠀⠀⢀⠞⠋⠀⠀⣷⣤⣀⣀⣀⠀⠀⠀⠀⠸⡇⠀\n"
                + "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢹⣿⣿⣿⣿⣿⣢⠄⠀⠀⡇⠀\n"
                + "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣾⣿⣿⣿⣿⣿⣿⡀⠀⠀⡇⠀\n"
                + "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⣿⣿⣿⣿⣿⣿⡇⠀⣀⣇⠀\n"
                + "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢻⣿⣿⣿⣿⣿⣿⣧⣴⣾⣻⡆\n"
                + "⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⣿⣿⣿⣿⣿⣿⣿⣿⣿⣸⣿⡇\n"
                + "⠀⠀⠀⠀⠀⠀⠀⠀⠀⢻⣿⣿⣭⣾⣿⣿⣿⠉⣛⢿⠿⠁\n"
                + "⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣿⣿⣷⣶⣿⣻⣿⣆⠙⣿⠀⠀\n"
                + "⠀⠀⠀⠀⠀⠀⠀⢀⣴⣿⣿⣿⣿⡿⣸⣔⣿⣿⡄⣿⠀⠀\n"
                + "⠀⠀⠀⠀⢀⣠⣶⣿⣿⣿⣿⣿⣿⣧⣼⣿⣿⣿⣿⡏⠀⠀\n"
                + "⠐⠶⠶⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠿⠇⠀⠀\n"
                + "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠉⠉⠉⠀⠀⠀⠀⠀⠀\n"
                + "⠀⠀⠀⠀⢠⢤⢤⠤⡤⡤⠄⢠⣤⡄⠠⠄⡤⣤⣤⡠⠄⠀");
    }

    static void apresentarMensagemVencedor() {
        //esta funcao apresenta a mensagem quando o usuario vence o jogo 
        System.out.println("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣾⡿⠳⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣤⡶⠶⢖⠦⣄⠀⠀⠀⠀⠀⠀⠀\n"
                + "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⣾⣷⡀⠀⠀⠀⠀⠀⠐⠋⠉⠉⠛⢷⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣰⠟⠁⠀⠀⢀⠇⠈⢳⠀⠀⠀⠀⠀⠀\n"
                + "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⡿⠋⠀⠀⠀⢀⣀⣠⠤⠤⠤⠤⠤⠤⠤⢌⣀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢰⢻⠀⠀⠀⠀⠈⠀⠀⢸⠇⠀⠀⠀⠀⠀\n"
                + "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣼⠁⣠⠤⠒⣋⡭⠤⠒⠒⠉⠉⡩⢟⣣⣤⣀⡢⣬⣉⠒⠤⣄⠀⠀⠀⠀⠀⠀⠀⠀⢼⠈⠃⠀⠀⠀⠀⠀⠀⡞⠀⠀⠀⠀⠀⠀\n"
                + "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⠖⣉⠴⠒⠉⠀⠀⠀⠀⠀⢀⣞⣴⠟⠋⠉⠛⢿⣾⣎⠑⢤⡀⠙⠢⣄⠀⠀⠀⠀⠀⠸⡄⠀⠀⠀⠀⠀⠀⣸⠃⠀⠀⠀⠀⠀⠀\n"
                + "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⡴⢋⡤⢊⣁⡀⠀⠀⠀⠀⠀⠀⠀⣞⣾⠃⠀⠀⠀⠀⠀⠹⣿⡄⠀⠱⡄⠀⠈⠑⣄⠀⠀⢀⣠⣽⠶⠶⠶⠒⠒⠒⠛⢤⣄⡀⠀⠀⠀⠀\n"
                + "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⠋⡴⢋⢔⣭⣴⣿⣷⣤⠀⠀⠀⠀⠰⣽⠃⠀⠀⠀⠀⠀⠀⠀⢹⣇⠀⠀⠘⡄⠀⠀⠈⢳⣶⠟⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠯⠻⣦⡀⠀⠀\n"
                + "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⡜⢡⠎⢠⢯⣿⠋⠁⠀⠈⠻⣷⠀⠀⠀⠀⡏⠀⠀⠀⠐⢷⢶⣄⠀⠀⣿⠀⠀⠐⠁⠀⠀⢰⡟⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠪⠙⣆⠀\n"
                + "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⡞⢠⠃⠀⣮⡿⠁⠀⠀⠀⠀⠀⠻⣇⠀⠀⢸⡇⠀⠀⢀⠀⣸⣷⣻⡄⠀⣿⠀⠀⠀⠀⠀⠀⣏⠓⠒⢀⣀⣀⣀⣀⣀⣀⣀⣀⠀⢠⠖⠀⠀⠀⠘⡄\n"
                + "⠀⠀⣀⣠⣤⣀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡞⢀⠇⠀⢰⣿⠇⠀⠀⠀⠀⠶⣶⡄⢹⠀⠀⠀⡇⠀⠀⣾⢹⣿⣿⣏⡇⠀⣿⠀⠀⣀⣤⡤⠤⣼⣶⠿⠛⠉⠀⠀⠀⠀⠀⠀⠉⠙⡇⠀⠀⠀⠀⠀⠀\n"
                + "⣠⢾⠋⠀⠀⠈⠻⡷⣄⠀⠀⠀⠀⠀⠀⢰⠁⠸⠀⠀⠸⣿⠀⠀⠀⠀⣄⣀⣷⣽⣸⠀⠀⠀⣇⠀⠀⠸⣞⣿⣅⣽⠁⢀⣇⣴⠞⠋⠁⠀⣼⠏⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠇⠀⠀⠀⠀⠀⠀\n"
                + "⡇⠘⠂⠀⠀⠀⠀⠁⠘⡆⠀⠀⠀⠀⠀⡏⠀⠀⠀⠀⢰⣿⠀⠀⠀⠀⣇⣿⣿⣿⣿⠀⠀⠀⠸⡄⠀⠀⠙⠧⠽⠃⠀⡼⠋⠀⠀⠀⠀⠀⣯⠦⠄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡀⠀⠀⠀⠀⠀⠀⠀\n"
                + "⢳⡀⠀⠀⠀⠀⠀⠀⢀⣹⣤⣤⣤⣤⣄⡇⠀⠰⠀⠀⠀⣿⠀⠀⠀⠀⢻⡽⠿⣾⢹⠀⠀⠀⠀⠻⡄⠀⠀⠀⠀⢠⠞⠁⠀⣀⣀⡀⠀⠀⠘⢧⡀⣠⣤⡶⠖⠛⠛⠛⠒⠒⡞⠀⠀⠀⠀⠀⠀⢀⠀\n"
                + "⠀⠉⠳⣄⠀⢀⡤⡺⠛⠉⠀⠀⠀⠀⠈⣻⢦⠀⠀⠀⠀⢻⡆⠀⠀⠀⠈⠻⠟⢁⡎⠀⠀⠀⠀⠀⠙⠦⣄⣀⣤⠟⠀⠀⠉⣀⣀⣀⡉⠂⠀⠀⣽⣏⠁⠀⠀⠀⠀⠀⠀⠀⢇⠀⠀⠀⠀⠀⢠⡞⠀\n"
                + "⠀⠀⠀⢈⣷⠋⠀⠁⠀⠀⠀⠀⠀⢈⣩⣤⣼⣧⣤⡀⠀⠀⠻⡄⠀⠀⠀⠀⢀⡼⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠋⠀⠀⣈⣭⠵⠒⠋⠉⠂⠀⠀⠹⡌⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⡴⠋⠀⠀\n"
                + "⠀⠀⠀⣾⠋⠀⠀⠀⠀⠀⢀⡤⠞⠉⠉⠀⠀⠀⠈⣻⡆⠀⣀⣙⡦⠤⣀⣤⠊⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣠⠴⠋⣡⡏⠀⠀⠀⠀⠀⠀⠀⠀⠙⠲⣄⡀⠀⠀⠀⠀⠀⠀⣀⣠⠴⠋⠁⠀⠀⠀\n"
                + "⠀⠀⢸⠇⠀⠀⠀⠀⢀⡶⠉⠀⠀⠀⠀⠀⠀⠀⠈⠁⡧⠋⠉⠁⠀⠀⠀⠘⠀⠀⠀⠀⠀⠀⠀⢀⣠⠴⠚⠉⠀⢀⣴⣿⠇⠀⠀⠀⠀⠀⠀⠀⠀⠀⣰⠁⠈⠉⠉⠉⠉⠉⠉⠁⠀⠀⠀⠀⠀⠀⠀\n"
                + "⠀⠀⢸⠀⠀⠀⠉⠑⢏⠀⠀⠀⠀⠀⠀⣀⣤⠶⠶⠾⣧⡀⠀⠀⠀⠀⠀⣤⣤⣤⣤⡤⠒⠒⠉⠁⠀⠀⣀⣤⣶⠿⢿⡿⠀⠀⠀⠀⠀⠀⠀⠀⢀⡶⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n"
                + "⠀⠀⠈⡆⠀⠀⠀⠀⠈⠇⠀⠀⢀⡤⠚⠉⠀⠀⠀⠐⠁⡇⠀⠀⠀⠀⠀⠘⢿⣿⣿⣿⣶⣶⣶⣶⣾⠿⣿⡟⠁⠀⣼⠃⠀⠀⠀⠀⠀⣠⠞⣠⡟⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n"
                + "⠀⠀⠀⠹⡄⠀⠀⠀⠀⠀⠀⠉⠻⡄⠀⠀⠀⠀⠀⠀⣰⠁⠀⠀⠀⠀⠀⠀⠈⢿⣿⣿⣿⣿⣿⣿⠃⣠⠏⠀⠀⣰⠏⠀⠀⠀⠀⠠⠞⢁⡴⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n"
                + "⠀⠀⠀⠀⠙⣄⠀⠀⠀⠀⠀⠀⠀⠊⠀⠀⠀⠀⢀⡴⠋⠳⢄⠀⠀⠀⠀⠀⠀⠀⠹⣿⣿⣿⣿⠁⠊⠀⠀⢀⡰⠋⠀⠀⠀⠀⠀⣠⡴⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n"
                + "⠀⠀⠀⠀⠀⠈⠑⠦⣀⡀⠀⠀⠀⠀⠀⣀⡠⠖⠋⠀⠀⠀⠀⠙⠢⢄⡀⠀⠀⠀⠀⠈⠛⢿⣇⣀⣀⣠⠴⠋⠀⠀⠀⢀⣀⠤⠚⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\n"
                + "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠉⠒⠒⠚⠉⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠙⠒⠤⢤⣀⣀⣀⣀⣀⣀⣀⣀⡠⠤⠖⠚⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀");

    }

    static void limpaTela() {
        //esta funcao da a impressao de limpar a tela 
        for (int i = 0; i < 25; i++)
        {
            System.out.println("");
        }
    }
}
