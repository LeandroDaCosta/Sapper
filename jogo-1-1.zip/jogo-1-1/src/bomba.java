public class bomba {
    int linhaBomba;
    int colunaBomba;
}
