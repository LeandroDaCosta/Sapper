public class data_nascimento {
    String dia;
    int mes;
    int ano;
}
