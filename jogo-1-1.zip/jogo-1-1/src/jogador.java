public class jogador {
    String nome;
    int dia,mes,ano;
    int pontuacao;
    jogador(){

    }
    jogador(String nom,int dd,int mm,int aa,int pont){
        nome = nom; dia = dd; mes = mm; ano = aa; pontuacao = pont;
    }
    public void listarJogador(){
        System.out.println(nome+"--------------------"+pontuacao+" pts");
    }
}
